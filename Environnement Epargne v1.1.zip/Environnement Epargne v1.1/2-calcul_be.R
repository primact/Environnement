
# Chargement du 'Be' et de l'actif correspondant a la situation centrale
central       <- get(load(paste(racine@address$save_folder$central, "best_estimate.RData", sep = "/")))
ACTIF_central <- print_alloc(central@canton@ptf_fin)[5, 1]

# Chargement des 'Be' pour chaque situation de choc de la formule standard
action_type_1 <- get(load(paste(racine@address$save_folder$action_type1, "best_estimate.RData", sep = "/")))
action_type_2 <- get(load(paste(racine@address$save_folder$action_type2, "best_estimate.RData", sep = "/")))
immo          <- get(load(paste(racine@address$save_folder$immo, "best_estimate.RData", sep = "/")))
spread        <- get(load(paste(racine@address$save_folder$spread, "best_estimate.RData", sep = "/")))
taux_up       <- get(load(paste(racine@address$save_folder$taux_up, "best_estimate.RData", sep = "/")))
taux_down     <- get(load(paste(racine@address$save_folder$taux_down, "best_estimate.RData", sep = "/")))
frais         <- get(load(paste(racine@address$save_folder$frais, "best_estimate.RData", sep = "/")))
mortalite     <- get(load(paste(racine@address$save_folder$mortalite, "best_estimate.RData", sep = "/")))
longevite     <- get(load(paste(racine@address$save_folder$longevite, "best_estimate.RData", sep = "/")))
rachat_up     <- get(load(paste(racine@address$save_folder$rachat_up, "best_estimate.RData", sep = "/")))
rachat_down   <- get(load(paste(racine@address$save_folder$rachat_down, "best_estimate.RData", sep = "/")))

# Calcul BE pour chaque situation


# si on veut enregistrer les resultats en base, l'objet Be doit avoir un argument base initialise
central@base <- new("DataBase", file_adress = paste(racine@root_address, "internal_ws/data/database", sep = "/"),
                    ecriture_base = T, choc_name = "central")
central@base@ecriture_base <- T # permet d ecrire en base
# central@base@ecriture_base <- F # n ecrit pas en base
BE_central_result       <- run_be(central, F, F)

action_type_1@base <- new("DataBase", file_adress = paste(racine@root_address, "internal_ws/data/database", sep = "/"),
                          ecriture_base = T, choc_name = "action_type_1")
action_type_1@base@ecriture_base <- T
BE_action_type_1_result <- run_be(action_type_1,F,F)

action_type_2@base <- new("DataBase")
action_type_2@base@ecriture_base <- T
BE_action_type_2_result <- run_be(action_type_2,F,F)

immo@base <- new("DataBase")
immo@base@ecriture_base <- T
BE_immo_result          <- run_be(immo,F,F)

spread@base <- new("DataBase")
spread@base@ecriture_base <- T
BE_spread_result        <-run_be(spread,F,F)

taux_up@base <- new("DataBase")
taux_up@base@ecriture_base <- T
BE_taux_up_result       <- run_be(taux_up,F,F)

taux_down@base <- new("DataBase")
taux_down@base@ecriture_base <- T
BE_taux_down_result     <- run_be(taux_down,F,F)

frais@base <- new("DataBase")
frais@base@ecriture_base <- T
BE_frais_result         <- run_be(frais,F,F)

mortalite@base <- new("DataBase")
mortalite@base@ecriture_base <- T
BE_mortalite_result     <- run_be(mortalite,F,F)

longevite@base <- new("DataBase")
longevite@base@ecriture_base <- T
BE_longevite_result     <- run_be(longevite,F,F)

rachat_up@base <- new("DataBase")
rachat_up@base@ecriture_base <- T
BE_rachat_up_result     <- run_be(rachat_up,F,F)

rachat_down@base <- new("DataBase")
rachat_down@base@ecriture_base <- T
BE_rachat_down_result   <- run_be(rachat_down,F,F)





# Extraction des best estimates calcules pour chaque choc
BE_central       <- BE_central_result$be@tab_be$be[1, 1]
BE_action_type_1 <- BE_action_type_1_result$be@tab_be$be[1, 1]
BE_action_type_2 <- BE_action_type_2_result$be@tab_be$be[1, 1]
BE_immo          <- BE_immo_result$be@tab_be$be[1, 1]
BE_spread        <- BE_spread_result$be@tab_be$be[1, 1]
BE_taux_up       <- BE_taux_up_result$be@tab_be$be[1, 1]
BE_taux_down     <- BE_taux_down_result$be@tab_be$be[1, 1]
BE_frais         <- BE_frais_result$be@tab_be$be[1, 1]
BE_mortalite     <- BE_mortalite_result$be@tab_be$be[1, 1]
BE_longevite     <- BE_longevite_result$be@tab_be$be[1, 1]
BE_rachat_up     <- BE_rachat_up_result$be@tab_be$be[1, 1]
BE_rachat_down   <- BE_rachat_down_result$be@tab_be$be[1, 1]


# Extraction des actifs calcules pour chaque choc
ACTIF_action_type_1 <- print_alloc(action_type_1@canton@ptf_fin)[5,1]
ACTIF_action_type_2 <- print_alloc(action_type_2@canton@ptf_fin)[5,1]
ACTIF_immo          <- print_alloc(immo@canton@ptf_fin)[5,1]
ACTIF_spread        <- print_alloc(spread@canton@ptf_fin)[5,1]
ACTIF_taux_up       <- print_alloc(taux_up@canton@ptf_fin)[5,1]
ACTIF_taux_down     <- print_alloc(taux_down@canton@ptf_fin)[5,1]


# Calcul des SCR marche par module
SCR_action_type_1 <- max(0, (ACTIF_central - BE_central) - (ACTIF_action_type_1 - BE_action_type_1))
SCR_action_type_2 <- max(0, (ACTIF_central - BE_central) - (ACTIF_action_type_2 - BE_action_type_2))
SCR_immo          <- max(0, (ACTIF_central - BE_central) - (ACTIF_immo - BE_immo))
SCR_spread        <- max(0, (ACTIF_central - BE_central) - (ACTIF_spread - BE_spread))
SCR_taux_up       <- max(0, (ACTIF_central - BE_central) - (ACTIF_taux_up - BE_taux_up))
SCR_taux_down     <- max(0, (ACTIF_central - BE_central) - (ACTIF_taux_down - BE_taux_down))
SCR_taux          <- max(SCR_taux_up, SCR_taux_down)

# Calcul des SCR life par module
SCR_mortalite    <- max(0, (ACTIF_central - BE_central) - (ACTIF_central - BE_mortalite))
SCR_longevite    <- max(0, (ACTIF_central - BE_central) - (ACTIF_central - BE_longevite))
SCR_rachat_up    <- max(0, (ACTIF_central - BE_central) - (ACTIF_central - BE_rachat_up))
SCR_rachat_down  <- max(0, (ACTIF_central - BE_central) - (ACTIF_central - BE_rachat_down))
SCR_rachat       <- max(SCR_rachat_up, SCR_rachat_down)
SCR_frais        <- max(0, (ACTIF_central - BE_central) - (ACTIF_central - BE_frais))

#--- Matrice de correlation - Module Action  ---
corrActionType1 <- c(1, 0.75) 
corrActionType2 <- c(0.75 , 1)
MatCorrAction   <- matrix(c(corrActionType1, corrActionType2), nrow = 2, dimnames = list(c("ActionType1", "ActionType2")))

#--- Matrice de correlation - Module Marche  ---
corrTaux      <- c(1, 0.5, 0.5, 0.5, 0.25) 
corrActions   <- c(0.5, 1, 0.75, 0.75, 0.25)
corrImmo      <- c(0.5, 0.75, 1, 0.5, 0.25)
corrSpread    <- c(0.5, 0.75, 0.5, 1, 0.25)
corrChange    <- c(0.25, 0.25, 0.25, 0.25, 1)
MatCorrMarche <- matrix(c(corrTaux, corrActions, corrImmo, corrSpread, corrChange),
                        nrow = 5, dimnames = list(c("Taux", "Actions", "Immo", "Spread", "Change"), 
                                                  c("Taux", "Actions", "Immo", "Spread", "Change")))

#--- Matrice de correlation - Module Vie ---
corrMort   <- c(1, -0.25, 0, 0.25)
corrLong   <- c(-0.25, 1, 0.25, 0.25)
corrRachat <- c(0, 0.25, 1, 0.5)
corrFrais  <- c(0.25, 0.25, 0.5, 1)
MatCorrVie <- matrix(c(corrMort, corrLong, corrRachat, corrFrais),
                     nrow = 4, dimnames = list(c("Mort", "Long", "Rachat","Frais"),
                                               c("Mort", "Long", "Rachat","Frais")))

#--- Matrice de correlation - Module BSCR  ---
corrMarche  <- c(1, 0.25)
corrVie     <- c(0.25, 1)
MatCorrBSCR <- matrix(c(corrMarche, corrVie), nrow = 2, dimnames = list(c("Marche", "VIE"),c("Marche", "VIE")))

# Calcul du SCR Action
vectSCRAction   <- t(rbind(SCR_action_type_1, SCR_action_type_2))
aggregerAction  <- function(ligne){sqrt(t(vectSCRAction[ligne, ]) %*% MatCorrAction %*% vectSCRAction[ligne, ])}
SCR_action      <- as.numeric(aggregerAction(1))

# Calcul du SCR Marche
vectSCRMarche   <- t(rbind(SCR_taux, SCR_action, SCR_immo, SCR_spread, SCR_change = 0))
aggregerMarche  <- function(ligne){sqrt(t(vectSCRMarche[ligne, ]) %*% MatCorrMarche %*% vectSCRMarche[ligne, ])}
SCRMarche       <- as.numeric(aggregerMarche(1))

# Calcul du SCR Vie
vectSCRVie  <- cbind(SCR_mortalite, SCR_longevite, SCR_rachat, SCR_frais)
aggregerVie	<- function(ligne){sqrt(t(vectSCRVie[ligne, ]) %*% MatCorrVie %*% vectSCRVie[ligne, ])}
SCRVie      <- as.numeric(aggregerVie(1))

# Calcul du BSCR
vectBSCR		  <- cbind(SCRMarche, SCRVie)
aggregerBSCR <- function(ligne){sqrt(t(vectBSCR[ligne, ]) %*% MatCorrBSCR %*% vectBSCR[ligne, ])}
BSCR         <- as.numeric(aggregerBSCR(1))

